FANTO AIM ASSIST - Android Studio project

This is source code for a visual-only crosshair overlay prototype.
It does not interact with Free Fire, detect targets, automate aiming, inject code, or modify game files.

Login password in this prototype: fanto

BUILD:
1. Install Android Studio on a computer.
2. Open the FantoAimAssist folder in Android Studio.
3. Allow Gradle to sync and install the Android SDK Platform 35 if prompted.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk.

The overlay requires the user to grant Android's "Display over other apps" permission.
