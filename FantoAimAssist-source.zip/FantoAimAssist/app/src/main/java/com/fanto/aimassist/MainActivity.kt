package com.fanto.aimassist

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val purple = Color.rgb(177, 90, 255)
    private var unlocked = false
    private var crosshairOn = false
    private var aimColor = purple
    private var aimSize = 24
    private var fovSize = 90
    private var opacity = 85
    private var aimStyle = "Cruz"
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 8, 18)
        window.navigationBarColor = Color.rgb(11, 8, 18)
        showLogin()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(11, 8, 18))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        val heading = TextView(this).apply {
            text = title
            textSize = 27f
            setTextColor(purple)
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
            setPadding(0, 10, 0, 4)
        }
        root.addView(heading)
        val sub = TextView(this).apply {
            text = "VISUAL EDITION · 1.0"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        root.addView(sub)
    }

    private fun showLogin() {
        base("FANTO AIM")
        val label = TextView(this).apply { text = "ACCESO AL PANEL"; setTextColor(Color.WHITE); textSize = 18f }
        root.addView(label)
        val pass = EditText(this).apply {
            hint = "Contraseña"
            setSingleLine(true)
            inputType = 129
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        root.addView(pass, match())
        val enter = button("DESBLOQUEAR")
        root.addView(enter, match())
        val error = TextView(this).apply { setTextColor(Color.RED); gravity = Gravity.CENTER }
        root.addView(error)
        enter.setOnClickListener {
            if (pass.text.toString() == "fanto") showPanel() else error.text = "Contraseña incorrecta"
        }
    }

    private fun showPanel() {
        base("FANTO AIM ASSIST")
        val preview = TextView(this).apply {
            text = "⊕\nVISTA PREVIA DE LA MIRA"
            gravity = Gravity.CENTER
            textSize = 25f
            setTextColor(aimColor)
            setBackgroundColor(Color.rgb(23, 16, 32))
            setPadding(12, 24, 12, 24)
        }
        root.addView(preview, match())
        addLabel("ESTILO DE MIRA")
        val styles = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Cruz", "Punto", "Círculo"))
            setSelection(listOf("Cruz", "Punto", "Círculo").indexOf(aimStyle).coerceAtLeast(0))
        }
        root.addView(styles, match())
        styles.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                aimStyle = listOf("Cruz", "Punto", "Círculo")[position]; refreshOverlay()
            }
        }
        addSlider("TAMAÑO", 8, 50, aimSize) { aimSize = it; refreshOverlay() }
        addSlider("CÍRCULO FOV (VISUAL)", 20, 150, fovSize) { fovSize = it; refreshOverlay() }
        addSlider("TRANSPARENCIA", 10, 100, opacity) { opacity = it; refreshOverlay() }
        addLabel("COLOR")
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf(purple, Color.WHITE, Color.CYAN, Color.GREEN, Color.RED).forEach { c ->
            val b = Button(this).apply { text = "●"; textSize = 18f; setTextColor(c); setBackgroundColor(Color.rgb(30, 20, 42)) }
            colors.addView(b, LinearLayout.LayoutParams(0, 54, 1f))
            b.setOnClickListener { aimColor = c; preview.setTextColor(c); refreshOverlay() }
        }
        root.addView(colors, match())
        val toggle = button(if (crosshairOn) "DESACTIVAR MIRA FLOTANTE" else "ACTIVAR MIRA FLOTANTE")
        root.addView(toggle, match())
        toggle.setOnClickListener {
            if (!crosshairOn) {
                if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    Toast.makeText(this, "Autoriza FANTO AIM y vuelve a la aplicación", Toast.LENGTH_LONG).show()
                } else {
                    crosshairOn = true; refreshOverlay(); showPanel()
                }
            } else {
                crosshairOn = false; stopService(Intent(this, CrosshairService::class.java)); showPanel()
            }
        }
        val note = TextView(this).apply {
            text = "La mira es una referencia visual independiente. No apunta automáticamente ni modifica Free Fire."
            setTextColor(Color.LTGRAY); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, 20, 0, 8)
        }
        root.addView(note, match())
    }

    override fun onResume() {
        super.onResume()
        if (unlocked && !crosshairOn && Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
            // Permission granted; user can activate the overlay from the panel.
        }
    }

    private fun refreshOverlay() {
        if (!crosshairOn) return
        val i = Intent(this, CrosshairService::class.java).apply {
            putExtra("size", aimSize); putExtra("fov", fovSize); putExtra("opacity", opacity)
            putExtra("color", aimColor); putExtra("style", aimStyle)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundServiceCompat(i) else startService(i)
    }

    private fun startForegroundServiceCompat(i: Intent) { startService(i) }
    private fun addLabel(s: String) { root.addView(TextView(this).apply { text = s; setTextColor(Color.WHITE); textSize = 14f; setPadding(0, 18, 0, 4) }) }
    private fun addSlider(name: String, min: Int, max: Int, initial: Int, changed: (Int) -> Unit) {
        addLabel("$name: $initial")
        val label = root.getChildAt(root.childCount - 1) as TextView
        val bar = SeekBar(this).apply { this.max = max - min; progress = initial - min; progressTintList = android.content.res.ColorStateList.valueOf(purple); thumbTintList = android.content.res.ColorStateList.valueOf(purple) }
        root.addView(bar, match())
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { val v = progress + min; label.text = "$name: $v"; changed(v) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }
    private fun button(s: String) = Button(this).apply { text = s; setTextColor(Color.WHITE); setBackgroundColor(purple) }
    private fun match() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 }
}
