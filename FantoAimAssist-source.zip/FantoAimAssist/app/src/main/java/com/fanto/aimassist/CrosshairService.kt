package com.fanto.aimassist

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.min

class CrosshairService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: AimView? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        val size = intent.getIntExtra("size", 24)
        val fov = intent.getIntExtra("fov", 90)
        val opacity = intent.getIntExtra("opacity", 85)
        val color = intent.getIntExtra("color", Color.MAGENTA)
        val style = intent.getStringExtra("style") ?: "Cruz"
        if (overlay == null) {
            overlay = AimView()
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            params = WindowManager.LayoutParams(220, 220, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
            wm.addView(overlay, params)
        }
        overlay?.configure(size, fov, opacity, color, style)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    inner class AimView : View(this@CrosshairService) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var size = 24f
        private var fov = 90f
        private var alpha = 217
        private var color = Color.MAGENTA
        private var style = "Cruz"
        fun configure(s: Int, f: Int, a: Int, c: Int, st: String) {
            size = s.toFloat(); fov = f.toFloat(); alpha = (a * 255 / 100).coerceIn(0, 255); color = c; style = st; invalidate()
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f
            paint.color = color; paint.alpha = (alpha * 0.55f).toInt(); paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f
            canvas.drawCircle(cx, cy, min(fov / 2f, 100f), paint)
            paint.alpha = alpha; paint.strokeWidth = 3f
            when (style) {
                "Punto" -> { paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, size / 5f, paint) }
                "Círculo" -> { paint.style = Paint.Style.STROKE; canvas.drawCircle(cx, cy, size / 2f, paint); paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 2f, paint) }
                else -> { paint.style = Paint.Style.STROKE; canvas.drawLine(cx - size / 2, cy, cx + size / 2, cy, paint); canvas.drawLine(cx, cy - size / 2, cx, cy + size / 2, paint); paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 2f, paint) }
            }
        }
    }
}
